
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} fmha_v2_d64_sw_paged_ragged_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_fmha_v2_d64_sw_paged_ragged_cuda_init(void **);
void _mlir_fmha_v2_d64_sw_paged_ragged_cuda_load_to_device(void **);
static inline void fmha_v2_d64_sw_paged_ragged_Kernel_Module_Load(fmha_v2_d64_sw_paged_ragged_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_fmha_v2_d64_sw_paged_ragged_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_fmha_v2_d64_sw_paged_ragged_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void fmha_v2_d64_sw_paged_ragged_Kernel_Module_Unload(fmha_v2_d64_sw_paged_ragged_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} fmha_v2_d64_sw_paged_ragged_Tensor_q_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} fmha_v2_d64_sw_paged_ragged_Tensor_kv_cache_pool_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} fmha_v2_d64_sw_paged_ragged_Tensor_kv_cache_page_list_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} fmha_v2_d64_sw_paged_ragged_Tensor_o_tensor_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_v2_d64_sw_paged_ragged_Tensor_cum_seqlen_q_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} fmha_v2_d64_sw_paged_ragged_Tensor_cum_seqlen_k_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_fmha_v2_d64_sw_paged_ragged__mlir_ciface_cutlass___call_context_paged_ragged_____main__FMHAV2Ampere_object_at__FakeTensorFloat16div1div164i64div64641_FakeTensorFloat16div1div1div1div1i64div1i64div1i64div11_FakeTensorInt32(void **args, int32_t num_args);

static inline int32_t cute_dsl_fmha_v2_d64_sw_paged_ragged_wrapper(fmha_v2_d64_sw_paged_ragged_Kernel_Module_t *module, fmha_v2_d64_sw_paged_ragged_Tensor_q_tensor_t *q_tensor, fmha_v2_d64_sw_paged_ragged_Tensor_kv_cache_pool_t *kv_cache_pool, fmha_v2_d64_sw_paged_ragged_Tensor_kv_cache_page_list_t *kv_cache_page_list, fmha_v2_d64_sw_paged_ragged_Tensor_o_tensor_t *o_tensor, fmha_v2_d64_sw_paged_ragged_Tensor_cum_seqlen_q_t *cum_seqlen_q, fmha_v2_d64_sw_paged_ragged_Tensor_cum_seqlen_k_t *cum_seqlen_k, int32_t max_seqlen_q, int32_t window_size_left, float attention_scale, int32_t sm_count, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[12] = {
        q_tensor, kv_cache_pool, kv_cache_page_list, o_tensor, cum_seqlen_q, cum_seqlen_k, &max_seqlen_q, &window_size_left, &attention_scale, &sm_count, &stream,
        &ret
    };
    _mlir_fmha_v2_d64_sw_paged_ragged__mlir_ciface_cutlass___call_context_paged_ragged_____main__FMHAV2Ampere_object_at__FakeTensorFloat16div1div164i64div64641_FakeTensorFloat16div1div1div1div1i64div1i64div1i64div11_FakeTensorInt32(args, 12);
    return ret;
}
