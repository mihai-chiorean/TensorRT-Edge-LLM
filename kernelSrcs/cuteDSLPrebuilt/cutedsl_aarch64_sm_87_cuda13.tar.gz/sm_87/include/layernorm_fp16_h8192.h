
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} layernorm_fp16_h8192_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_layernorm_fp16_h8192_cuda_init(void **);
void _mlir_layernorm_fp16_h8192_cuda_load_to_device(void **);
static inline void layernorm_fp16_h8192_Kernel_Module_Load(layernorm_fp16_h8192_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_layernorm_fp16_h8192_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_layernorm_fp16_h8192_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void layernorm_fp16_h8192_Kernel_Module_Unload(layernorm_fp16_h8192_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} layernorm_fp16_h8192_Tensor_output_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} layernorm_fp16_h8192_Tensor_x_t;


typedef struct {
    void *data;
} layernorm_fp16_h8192_Tensor_gamma_t;


typedef struct {
    void *data;
} layernorm_fp16_h8192_Tensor_beta_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_layernorm_fp16_h8192__mlir_ciface_cutlass_aot_adapter_FakeTensorFloat16div1819281921_FakeTensorFloat16div1819281921_FakeTensorFloat1681921_FakeTensorFloat1681921___CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_layernorm_fp16_h8192_wrapper(layernorm_fp16_h8192_Kernel_Module_t *module, layernorm_fp16_h8192_Tensor_output_t *output, layernorm_fp16_h8192_Tensor_x_t *x, layernorm_fp16_h8192_Tensor_gamma_t *gamma, layernorm_fp16_h8192_Tensor_beta_t *beta, int64_t rows, float eps, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[8] = {
        output, x, gamma, beta, &rows, &eps, &stream,
        &ret
    };
    _mlir_layernorm_fp16_h8192__mlir_ciface_cutlass_aot_adapter_FakeTensorFloat16div1819281921_FakeTensorFloat16div1819281921_FakeTensorFloat1681921_FakeTensorFloat1681921___CUstream0x0(args, 8);
    return ret;
}
